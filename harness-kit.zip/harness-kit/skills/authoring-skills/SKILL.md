---
name: authoring-skills
description: Authors and audits SKILL.md files and their supporting reference directories. Covers frontmatter fields and hard character limits, description text that triggers reliably without over-triggering, progressive disclosure and file layout, argument handling, discovery and precedence rules, and evaluation-driven iteration on skill quality. Use this skill whenever creating or editing a skill, whenever a skill fires at the wrong times or fails to fire when it should, and whenever converting a long prompt, runbook or slash command into a skill.
---

# Authoring skills

A skill is progressive disclosure with a trigger attached. The frontmatter is always in context; the body loads when the skill fires; reference files load only when the body points at them. Getting the layering right is most of the work, and getting the description right is the rest.

## The three levels

| Level | Loaded | Budget |
|---|---|---|
| Frontmatter: name and description | Always, for every skill installed | Keep it tight; this is a tax on every conversation |
| SKILL.md body | When the skill triggers | Under 500 lines |
| Reference files | Only when the body points at them | Effectively unlimited |

The practical consequence: long reference material is nearly free, and a bloated description is expensive. Push detail down a level rather than trimming it away.

## Frontmatter

```yaml
---
name: skill-name
description: <what it does, and when to use it>
---
```

Hard limits: `name` at 64 characters, `description` at 1024 characters. Both are enforced.

Optional fields worth knowing: `allowed-tools`, `context: fork` (runs the skill as an isolated subagent with its own context window), `model`, `effort`, `argument-hint`, `disable-model-invocation`, `user-invocable`. Full list in `references/frontmatter-and-descriptions.md`.

For personal and project skills, the directory name determines the invoking command; `name` is the display label. This trips people up when the two disagree.

## Writing the description

This is the entire triggering mechanism. The model sees the description and nothing else when deciding whether to consult the skill.

Write it as: what the skill does, then the specific conditions that should invoke it. Include the vocabulary a user would actually use, and include cases where the user would not name the skill's subject explicitly.

Skills under-trigger more often than they over-trigger. Lean slightly pushy. Naming the adjacent situations where the skill applies is what converts a description from documentation into a router.

- Weak: "Guidance for writing hooks."
- Strong: "Writes and audits Claude Code hooks, slash commands and settings.json permission rules. Use whenever a rule should be enforced deterministically rather than prompted, whenever editing hooks or commands, and whenever a harness needs a guardrail that a model cannot talk itself out of."

Third person, present tense. Do not put "when to use" guidance in the body; it belongs entirely in the description, because the body is not loaded at decision time.

## Structuring the body

Aim for a workflow the model can follow, not an essay. Imperative form. Explain why a rule exists where the reasoning helps the model generalize; skip the explanation where the rule is arbitrary.

A structure that works for harness-facing skills:

1. One or two sentences framing what the skill is actually for.
2. The decision or workflow, in the order it happens.
3. Tables where the content is a lookup.
4. Pointers to reference files, with a sentence each on when to read them.
5. A quality checklist.

Keep the body under 500 lines. If it grows past that, add a layer of hierarchy rather than trimming content: move the detail into `references/` and leave a pointer.

## Reference file layout

```
skill-name/
├── SKILL.md
└── references/
    ├── topic-a.md
    └── topic-b.md
```

One level deep. Nested reference trees are hard for the model to navigate and tend to go unread. Split by domain rather than by document length, so the model can load exactly the branch it needs. For files over about 300 lines, add a table of contents at the top.

Point at reference files explicitly from SKILL.md, with a short statement of when each one is relevant. A reference file that SKILL.md does not mention will never be read.

## Splitting versus merging

Split a skill when it covers two domains that are used independently, or when one branch is vendor-specific and the other is not. A model loading the whole thing to use half of it is a signal to split.

Merge when two skills always fire together, or when their descriptions overlap enough that the model picks arbitrarily between them. Overlapping descriptions are worse than a single larger skill.

## Iterating

Test with the models that will actually trigger the skill, not just the strongest one available. A description that routes correctly for a frontier model may not route for a cheaper one running a subagent.

Write two or three realistic prompts, in the phrasing a real user would use, and check that the skill fires and produces what you expected. Adjust the description first when triggering is wrong, and the body when the output is wrong. More detail in `references/evaluation-driven-dev.md`.

## Quality checklist

- [ ] `name` under 64 characters, `description` under 1024
- [ ] Description states what it does **and** when to invoke it
- [ ] Description includes cases where the user would not name the subject explicitly
- [ ] No "when to use" guidance stranded in the body
- [ ] Body under 500 lines
- [ ] Reference files one level deep, split by domain
- [ ] Every reference file is pointed at from SKILL.md with a reason to read it
- [ ] Table of contents on reference files over about 300 lines
- [ ] No trigger overlap with a sibling skill
- [ ] Tested with the cheapest model that will need to trigger it
