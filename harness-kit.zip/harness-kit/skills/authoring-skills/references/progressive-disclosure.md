# Progressive disclosure

The design constraint that shapes every other decision in skill authoring.

## The cost model

| Level | When loaded | Cost |
|---|---|---|
| name + description | Every conversation, for every installed skill | High. This is a permanent tax |
| SKILL.md body | On trigger | Moderate. Bounded by the 500-line guidance |
| `references/*.md` | Only when the body points at them and the model follows | Near zero until used |

This inverts normal documentation instincts. In a document you optimize for a reader going front to back. In a skill you optimize for a model that reads the description always, the body sometimes, and any given reference file rarely.

The consequence: do not compress reference content to save space. Move it down a level. A 400-line reference file that loads twice a month is cheaper than 40 lines added to a description that loads every conversation.

## Where content belongs

**Description**: what it does, when to use it. Nothing else.

**Body**: the decision procedure, the workflow, lookup tables that are used most times the skill fires, and pointers.

**References**: exhaustive field lists, full API surfaces, long before-and-after catalogs, vendor-specific detail, anything used by one branch of the workflow.

A test: if the model would need this content on more than half of invocations, it belongs in the body. Otherwise it goes in a reference file.

## Splitting by domain

When a skill spans variants, split the references by variant so exactly one loads:

```
routing-models/
├── SKILL.md          (selection logic)
└── references/
    ├── vendor-a.md
    └── vendor-b.md
```

Do not split by document size. Splitting a coherent topic across two files because one got long forces the model to load both, which is worse than one long file.

## One level deep

Nested reference trees go unread. The model follows one pointer reliably, two occasionally, three almost never. If a reference file needs to point at another reference file, the split is wrong; restructure so SKILL.md points directly at both.

## Pointers

A reference file that SKILL.md does not mention will never load. Every pointer needs a reason attached:

```
- `references/effort-guide.md`: what each level does, when to step up or down
- `references/fable-and-mythos.md`: Tier A only. Refusal handling, long-run patterns
```

Note the second one carries a precondition. That is the useful pattern: tell the model when the file is irrelevant so it does not load it speculatively.

## Tables of contents

Reference files over roughly 300 lines get a table of contents at the top. The model reads the top of the file, decides whether to continue, and can jump. Without one it either reads the whole file or abandons it.

## Scripts and assets

Two directories beyond `references/`:

- `scripts/`: executable code for deterministic or repetitive work. Scripts can run without their contents being loaded into context, which makes them the cheapest form of skill content.
- `assets/`: templates, fonts, icons, files used in the output rather than read for guidance.

Prefer a script over prose instructions wherever the task is deterministic. "Run this script" costs a few tokens; "here are the twelve steps to do this by hand" costs hundreds and executes less reliably.
