# SKILL.md frontmatter and description craft

Verified against Claude Code documentation as of 25 July 2026.

## Fields

| Field | Constraint | Notes |
|---|---|---|
| `name` | max 64 chars | Display label for personal and project skills; the invoking command comes from the directory name. For plugin skills it sets the last command segment |
| `description` | max 1024 chars | The trigger. Technically optional, effectively required |
| `allowed-tools` | space or comma separated | Tool allowlist for the skill |
| `context` | `fork` | Runs the skill as an isolated subagent with its own context window |
| `agent` | agent name | Runs the skill under a specific agent |
| `model` | model alias or id | Overrides model for the skill |
| `effort` | `low` to `max` | Overrides effort for the skill |
| `argument-hint` | string | Displayed to the user when invoking |
| `disable-model-invocation` | boolean | User-invocable only; the model will not trigger it |
| `user-invocable` | boolean | Whether it appears as a slash command |
| `hooks` | object | Skill-scoped hooks |
| `license`, `compatibility`, `metadata`, `version` | various | Distribution metadata |

Boolean fields accept yes/no, on/off and 1/0 in recent versions; older versions accept only true/false.

## Discovery and precedence

Highest first: enterprise, personal (`~/.claude/skills/`), project (`.claude/skills/`). A same-named skill overrides a bundled one. Plugin skills are namespaced `plugin:skill`.

Skills load from nested `.claude/skills/` directories and from parent directories up to the repository root. SKILL.md text changes are picked up live within a session; creating a new top-level skills directory requires a restart.

## Arguments

`$ARGUMENTS` interpolates the full argument string. Named positional arguments interpolate as `$name`. If `$ARGUMENTS` does not appear in the body, Claude Code appends `ARGUMENTS: <value>` to the content automatically.

Dynamic context injection: a backtick-wrapped shell command prefixed with `!` runs and inlines its output before the model reads the skill. Useful for injecting current branch, dirty file list, or a config value. Use sparingly; it runs every invocation.

## Description craft

The description is matched against the user's request. Nothing else about the skill is visible at that moment.

**Formula:** `<what it does>. <When to use it, including adjacent phrasings>.`

**Include the trigger vocabulary.** If users say "second opinion" rather than "review", the word "review" alone will miss. List the phrasings.

**Include the implicit cases.** The highest-value clause in most descriptions is the one covering requests where the user does not name the subject. "Even when the user does not mention model names explicitly" converts a passive description into an active router.

**Third person, present tense.** "Writes and audits X" not "You will write X" or "Use this to write X".

**Do not describe the mechanism.** The description sells the outcome and the trigger, not the implementation. Detail belongs in the body.

**Avoid trigger overlap.** Two skills whose descriptions both match a request produce arbitrary selection. When auditing a skill set, read every description in sequence and look for pairs that would both match the same phrasing.

## Under-triggering versus over-triggering

Under-triggering is far more common. Models consult skills for tasks they cannot easily handle alone, so simple one-step requests may not trigger a skill even with a perfect description.

The implication for testing: use substantive, multi-step test prompts. A test prompt like "read this file" will not trigger anything and tells you nothing about description quality.

If a skill over-triggers, the usual cause is a description written broadly enough to match its whole domain rather than its specific job. Narrow the conditions, do not shorten the description.
