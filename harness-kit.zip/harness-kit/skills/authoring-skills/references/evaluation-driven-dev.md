# Iterating on a skill

## The loop

1. Draft the skill.
2. Write two or three realistic test prompts, phrased the way a real user would phrase them.
3. Run them and look at what happens.
4. Fix the description if triggering was wrong; fix the body if the output was wrong.
5. Repeat.

Most skills need two or three passes. The first draft is usually right about content and wrong about triggering.

## Writing test prompts

Use substantive, multi-step prompts. Models consult skills for work they cannot easily do alone, so a trivial prompt will not trigger a skill regardless of how good the description is, and tells you nothing.

Cover three cases:

- **The obvious invocation.** The user names the subject directly.
- **The implicit invocation.** The user describes a situation the skill covers without naming it. This is where most descriptions fail.
- **The near miss.** A request that is adjacent but should *not* trigger this skill. Confirms you have not over-broadened.

## Diagnosing failures

| Symptom | Cause | Fix |
|---|---|---|
| Never fires | Description states the role but not the invocation conditions | Add explicit "use when" clauses with real user phrasing |
| Fires on unrelated requests | Description covers the whole domain rather than the specific job | Narrow the conditions; do not just shorten |
| Fires but ignores reference files | Pointers missing or lack a reason to follow them | Add a one-line reason to each pointer |
| Fires and produces the wrong shape | Output format underspecified in the body | Add an explicit template |
| Two skills compete | Overlapping trigger conditions | Sharpen the boundary in both descriptions, or merge |

## Testing across models

Test with the cheapest model that will need to trigger the skill, not only the strongest one. Descriptions that route correctly for a frontier model can fail for a smaller model running as a subagent. If a skill must work in both places, tune the description against the weaker one.

## Auditing a set of skills

Read every description in sequence, ignoring the bodies. That is what the routing model sees. Look for:

- Pairs that would both match the same request
- Descriptions that describe implementation rather than trigger conditions
- Missing vocabulary a user would plausibly use
- Skills whose entire content would fit as a line in CLAUDE.md or a hook

The last one matters. A skill is for procedural knowledge that loads on demand. A single always-true rule belongs in CLAUDE.md; a deterministic constraint belongs in a hook.

## When to stop

A skill is done when it triggers on the implicit cases, does not trigger on the near miss, and produces the right shape without further prompting. Additional polish on the body has diminishing returns compared with fixing a description that misroutes.
