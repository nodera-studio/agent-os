# Prompt migration: Claude 4.x to Claude 5

Apply these to any prompt a Claude 5 model consumes: agent system prompts, slash commands, skill bodies, CLAUDE.md, always-on preambles.

The governing principle is subtraction. Anthropic removed over 80 percent of Claude Code's system prompt for the Claude 5 generation with no measurable loss on their coding evaluations. Most Claude 4.x-era scaffolding existed to compensate for behaviors Claude 5 no longer exhibits, and leaving it in costs tokens and, in several cases, quality.

## The deletions

**Standing verification instructions.** Opus 5 verifies its own work and iterates without being told. Explicit verification instructions cause over-verification.

- Before: "Include a final verification step for any non-trivial task." / "Use a subagent to verify your changes."
- After: delete.
- Keep: independent, author-blind verification performed by a *different* agent that did not write the code. That is an external signal, not self-checking.

**Double-check and re-verify language.**

- Before: "Before you finish, double-check your answer." / "Re-verify your reasoning before responding."
- After: delete. This compounds with the model's own self-correction.

**Anti-laziness emphasis.**

- Before: "CRITICAL: You MUST use this tool. NEVER skip this step. ALWAYS check EVERY file."
- After: "Use this tool to inspect file structure before editing."

**Hard rails the model no longer needs.** Rules like "avoid deleting files without asking" or "do not produce unsolicited markdown plans" were necessary on older models. Test whether Claude 5 already follows them, and delete the ones it does.

**Prescriptive chain-of-thought.** Adaptive thinking is on by default. Step-by-step reasoning plans in the prompt can degrade performance.

- Before: "Think step by step. First consider X, then evaluate Y, then conclude Z."
- After: delete, and set effort instead.

## The replacements

**Conciseness, replaced with explicit length calibration.** Effort does not shorten visible output, and Claude 5 defaults to longer responses than Opus 4.x.

- Before: "Be concise."
- After: "Lead with the answer. Keep the response focused and brief, with most of the length on the substance rather than preamble or recap. Give a high-level summary unless depth is requested."

**Written deliverable length, which is a separate problem.** Claude 5 writes long files.

- Add: "Match document length to what the task needs. Do not pad with filler sections, redundant summaries, or boilerplate."

**Suppression language, replaced with coverage-first.** Claude 5 follows suppression instructions literally and silently drops real findings.

Find and remove: "only report critical issues", "be conservative", "do not nitpick", "focus on high-severity only", "skip minor issues", "only flag important problems".

Replace with:

```
Report every issue you find, including ones you are uncertain about or
consider low severity. Do not filter for importance or confidence at this
stage; a separate step will do that. Coverage is the goal here: surfacing a
finding that later gets filtered out is better than silently dropping a real
bug. For each finding, include a confidence level and an estimated severity
so a downstream filter can rank them.
```

This assumes a downstream filter exists. If none does, add one rather than reintroducing suppression at the finding stage.

**Scope, which now needs stating.** Opus 5 expands scope readily.

- Add: "Deliver what was asked at the scope intended. Make routine judgment calls without checking in. Finish the whole task and stop short of work beyond it."

**Delegation, which now needs capping.** Opus 5 delegates readily.

- Add: "Delegate only for large, genuinely independent, parallelizable tracks. Do not delegate work you can finish in a handful of tool calls, and do not delegate verification of your own work."

**Narration, which now needs tuning rather than forcing.** Claude 5 narrates progress natively; older harnesses forced interim status messages.

- Before: "Provide a quick summary after completing tool use."
- After: "One sentence before the first tool call. Brief updates only on important findings. Lead with the outcome at the end."

## Instruction-following changes to audit for

Claude 5 follows instructions more literally and generalizes less silently from one item to another. Two consequences:

- Hedged language like "usually", "try to", and "where possible" may be read narrowly. Say what you mean.
- Examples are followed closely. Audit every example in a prompt for behavior you do not actually want, because it will be reproduced.

## Sonnet 5 specifics

Sonnet 5 defaults to `high`. If you previously ran Sonnet 4.6 with thinking off, try Sonnet 5 with thinking on at lower effort instead; it is frequently a better tradeoff. Revisit `max_tokens`, which now covers thinking plus text.
