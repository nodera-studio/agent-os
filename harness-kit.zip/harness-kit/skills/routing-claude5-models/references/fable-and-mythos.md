# Fable 5 and Mythos 5

**Tier A only.** If the harness cannot reach Fable, skip this file; Opus 5 is your ceiling and the routing table in SKILL.md is complete without it.

## What they are

Fable 5 and Mythos 5 are the same underlying model at Anthropic's frontier tier, released 9 June 2026. Fable is the generally available version with additional safeguards for biology, cybersecurity, and LLM research and development. Mythos is the version without them, restricted to a small number of trusted organizations under Project Glasswing. Assume Mythos is unavailable.

Note for accuracy if the topic comes up: Anthropic suspended access to both models on 12 June 2026 to comply with US Department of Commerce export controls, and restored access on 1 July 2026 after those controls were lifted.

## When Fable is worth it

Rarely. Fable is $10 in and $50 out per MTok against Opus 5's $5 and $25, and its time to first token at maximum effort is roughly 110 seconds because adaptive thinking always runs before the first token. Opus 5 leads Fable on most published evaluations while costing half as much.

The one durable case: a single task that legitimately runs for hours or days without human checkpoints, where the premium buys sustained coherence rather than a better first answer. Multi-hour autonomous refactors, long unattended migration runs. Not code review. Not orchestration of a normal wave. Not anything a human is waiting on.

Default posture: Opus 5 everywhere, Fable reserved and justified per use.

## Prompting Fable specifically

**Never ask it to show or explain its reasoning.** Instructions like "show your reasoning" or "explain your internal reasoning" trigger a `reasoning_extraction` refusal, which silently falls back to an older model. Read the structured thinking blocks instead.

**Handle refusals in client code.** Check for `stop_reason: "refusal"` and fall back to Opus 5 rather than surfacing a failure. Anthropic also offers automatic API fallback for flagged requests; turn it on.

**Use a progress tool for long runs.** A `send_to_user` style tool lets the model report verbatim progress during a multi-hour run without ending its turn.

**Prefer fresh-context verifier subagents over self-critique.** On long runs this outperforms asking the model to review its own output, because the verifier has not accumulated the same assumptions.

**Dispatch subagents asynchronously.** Non-blocking dispatch keeps the main loop productive across long horizons.

**Separate assessment from action.** Fable will otherwise make changes when you wanted a diagnosis. Add: "When the user is describing a problem, report findings and hold the fix until asked."

**Give it a memory file.** Long-horizon runs compound lessons when the model can persist notes across context refreshes.

## Effort on Fable

Effort is the primary intelligence, latency, and cost dial. Default `high`; step to `xhigh` for capability-sensitive work. Lower effort on Fable frequently exceeds `xhigh` on prior-generation models, so stepping down is cheaper than it feels.

## Mixed-tier harnesses

If the same skill set deploys to both Tier A and Tier B harnesses, do not fork the routing table. Keep one table with Fable marked Tier A, and let the tier check at the top of SKILL.md gate it. Forked tables drift.
