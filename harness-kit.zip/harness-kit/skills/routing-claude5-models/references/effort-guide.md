# Effort on Claude 5

`output_config.effort` is the single control for reasoning depth. Values: `low`, `medium`, `high` (default), `xhigh`, `max`.

## What effort actually does

Effort is a behavioral signal across all output tokens, not a hard cap and not a thinking-only control. It affects thinking volume, how many tool calls the model makes, and how thoroughly it pursues a task. It does not reliably shorten the visible response. If you want a shorter answer, prompt for a shorter answer.

Lower effort means fewer tool calls. This matters for agentic roles: a retrieval agent at `low` may stop searching earlier than you expect.

## Choosing a level

| Level | Use for | Notes |
|---|---|---|
| `low` | Classification, lookup, single-pass checks, high-volume fan-out | Pair with an explicit checklist when the task has several parts, since low effort scopes tightly |
| `medium` | Code generation from a spec, tool-driven workflows, test writing, retrieval | The workhorse for mechanical roles on Sonnet 5 |
| `high` | Default. Review, audit, most orchestration | Do not run review or audit below this |
| `xhigh` | Implementation, debugging, hard planning waves | The go-deep tier for coding and agentic work |
| `max` | Frontier problems and ceiling testing | Prone to overthinking on structured-output tasks. Not a general quality tier |

The practical rule: start at `high`, step to `xhigh` where a measured gain appears, and use `low` and `medium` liberally as the primary cost and latency lever wherever your evals hold. On Fable 5 specifically, lower effort often exceeds `xhigh` performance on prior-generation models, so the step-down is cheaper than instinct suggests.

## Effort and prompt caching

Effort is part of the cache key. Changing effort between requests in the same conversation invalidates the cache and forces a full re-read of the prefix. Consequences for harness design:

- Vary effort **across** workloads, not **within** a session.
- If a workflow legitimately needs a cheap first pass and an expensive second pass, run them as two agents with separate contexts rather than one agent that changes effort mid-stream.
- Model switches, tool-set changes, and compaction also invalidate. Freeze the tools and system prefix for the life of a session where you can.

## Effort and thinking

Adaptive thinking is on by default on Claude 5. Thinking cannot be disabled at `xhigh` or `max`; attempting it returns 400. If a role genuinely needs thinking off, cap it at `high` or below.

Raw chain of thought is never returned. Set `thinking.display` explicitly if the harness surfaces reasoning to a user or to a downstream parser. The per-model default is not clearly documented; do not rely on it.

## Effort in Claude Code

Subagent frontmatter accepts an `effort` field with the same values. One reference indicates `max` is Opus-only in that context. Where a harness sets a session-level effort, subagent frontmatter effort applies to that subagent's own turns.
