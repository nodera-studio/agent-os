# Claude 5 model specifications

Verified against Anthropic documentation as of 25 July 2026. Re-check before mass edits; this generation ships frequently.

## Lineup

| Model | API string | In / Out per MTok | Context | Effort levels | Role fit |
|---|---|---|---|---|---|
| Claude Opus 5 | `claude-opus-5` | $5 / $25 | 1M | low, medium, high, xhigh, max | Frontier coding, orchestration, long-horizon agents |
| Claude Fable 5 | `claude-fable-5` | $10 / $50 | 1M, 128k out | low, medium, high, xhigh, max | Hardest multi-day autonomous work. Tier A only |
| Claude Mythos 5 | `claude-mythos-5` | gated | 1M | same as Fable | Not generally available. Project Glasswing partners only |
| Claude Sonnet 5 | `claude-sonnet-5` | $2 / $10 intro to 31 Aug 2026, then $3 / $15 | 1M, 128k out | low, medium, high, xhigh, max | Mechanical roles, tests, docs, retrieval |
| Claude Haiku 4.5 | `claude-haiku-4-5` | $1 / $5 | 200k, 64k out | see caveat below | Cheap classifier, high-volume routing |

Opus 5 released 24 July 2026. Fable 5 and Mythos 5 released 9 June 2026. Fable 5 and Mythos 5 share one underlying model; Mythos is the variant without the added safeguards, restricted to approved partners. Treat Mythos as unavailable unless you know otherwise.

## Effort support matrix

`max`: Fable 5, Mythos 5, Opus 5, Opus 4.8, Opus 4.7, Opus 4.6, Sonnet 5, Sonnet 4.6.

`xhigh`: Fable 5, Mythos 5, Opus 5, Opus 4.8, Opus 4.7, Sonnet 5. Note that supporting `max` does not imply supporting `xhigh`.

Default on Opus 5 and Sonnet 5 is `high`. Passing `effort: "high"` is identical to omitting the parameter.

### Haiku 4.5 caveat, UNVERIFIED

Haiku 4.5 is not listed in Anthropic's published effort support matrix, which enumerates the Opus, Sonnet, Fable and Mythos lines only. Two safe options: omit `output_config.effort` on Haiku roles entirely, which is always valid, or verify once and record the answer here.

```bash
curl https://api.anthropic.com/v1/messages \
  -H "x-api-key: $ANTHROPIC_API_KEY" \
  -H "anthropic-version: 2023-06-01" \
  -H "content-type: application/json" \
  -d '{"model":"claude-haiku-4-5","max_tokens":16,
       "output_config":{"effort":"low"},
       "messages":[{"role":"user","content":"hi"}]}'
```

A 200 means effort is supported. A 400 naming the parameter means omit it.

## Tokenizer

Sonnet 5 and Fable 5 use the tokenizer introduced with Opus 4.7, which counts roughly 1.0 to 1.35 times more tokens for identical text than the Opus 4.6-era tokenizer. Re-baseline cost against real workloads rather than trusting a per-token rate card comparison against older models.

## max_tokens

`max_tokens` caps thinking plus visible output on Claude 5, not visible output alone. Set it to at least 64000 for any role running at `xhigh` or `max`, otherwise the model can exhaust the budget mid-thought and return truncated work.

## Rejected parameters

These return HTTP 400 on Claude 5 and are the most common migration failures:

- `thinking: {type: "enabled", budget_tokens: N}`. Removed. Use `output_config.effort`.
- Assistant-message prefilling. Removed in the 4.6 and 4.7 line, still removed.
- `thinking: {type: "disabled"}` combined with effort `xhigh` or `max`.
- Non-default sampling parameters on some configurations. Prefer leaving temperature and top_p at defaults on Claude 5 reasoning paths.
