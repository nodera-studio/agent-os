---
name: routing-claude5-models
description: Selects the Claude 5 model and effort level for every subagent role in a Claude Code harness, and rewrites Anthropic-facing prompts for Claude 5 behavior. Covers Opus 5, Sonnet 5, Haiku 4.5, Fable 5 and Mythos 5, the effort levels low through max, adaptive thinking, prompt caching interactions, and Claude 4.x to Claude 5 migration. Use this skill whenever assigning or changing a model or effort on an agent, whenever writing or editing any prompt that a Claude model will consume, and whenever a harness is being audited or migrated to the Claude 5 generation, even when the user does not mention model names explicitly.
---

# Routing Claude 5 models

Two jobs: pick the model and effort for a role, and make the prompt suit the model you picked. Doing only the first leaves Claude 4.x-era prompt scaffolding in place, which on Claude 5 actively costs quality.

## Step 1: establish the capability tier

Harnesses differ in what they can reach. Detect the tier before routing, then stay in it.

| Tier | Ceiling model | Typical context |
|---|---|---|
| **A** | Fable 5 available | Direct API key, or a Max plan with Fable access |
| **B** | Opus 5 is the ceiling | Enterprise or managed deployments without Fable |

Detect by checking configured model availability, or by reading a harness-level marker if one exists. When unsure, assume Tier B. Tier B is a strict subset of Tier A routing, so a Tier B answer is always safe; a Tier A answer given to a Tier B harness produces agents that fail at dispatch.

Everything below is Tier B unless marked Tier A.

## Step 2: route the role

Match the role by what it does, not by what it is called. Harnesses name the same role differently.

| Role shape | Model | Effort | Why |
|---|---|---|---|
| Orchestrator, planner, architect | Opus 5 | `high`, `xhigh` on hard waves | Long-horizon planning and dispatch is where Opus 5 gains most. Reserve `xhigh` for genuinely hard waves; it is not a free upgrade |
| Code writer, implementer | Opus 5 | `xhigh` | Leads real-repository coding. Set `max_tokens` to at least 64000 |
| Code reviewer, auditor | Opus 5 | `high` | Review accuracy holds at `high`. See the coverage-first prompt rule below |
| Debugger, root-cause investigator | Opus 5 | `xhigh` | Depth pays here. Pair with a fresh-context adversary rather than self-critique |
| Test writer, conformance | Sonnet 5 | `medium` | Mechanical and spec-driven. Sonnet 5 at `medium` is roughly Sonnet 4.6 at `high` |
| Researcher, retriever, explorer | Sonnet 5 | `medium` | Context gathering, not reasoning. Keep cheap and parallel |
| Doc writer, changelog, summarizer | Sonnet 5 | `low` to `medium` | Low stakes. Calibrate length explicitly; Claude 5 writes long by default |
| Classifier, router, single-pass check | Haiku 4.5 | `low` (see caveat) | Sub-second decisions with no reasoning requirement |
| **Tier A only:** multi-day autonomous run | Fable 5 | `high` to `xhigh` | Only when one task legitimately runs for hours. Read `references/fable-and-mythos.md` first |

Decision framework when the table does not obviously fit. Apply top-down, first match wins:

1. Does it dispatch three or more subagents and merge contradictory outputs? Opus 5.
2. Does it make decisions that other agents consume as fact? Opus 5.
3. Does it produce findings from review, audit, or debugging? Opus 5.
4. Does it generate code or tests from a plan someone else made? Sonnet 5.
5. Does it run a tool, parse output, and report? Sonnet 5.
6. Is it a classification or a lookup? Haiku 4.5.

Two rules that override the table. Do not run review or audit roles below `high`; Claude 5 scopes work tightly at low effort and will under-report. Hold effort constant within a cached session, because effort is part of the cache key and changing it forces a full re-read.

## Step 3: fix the prompt for Claude 5

Routing without this step is half a job. Full before and after list in `references/prompting-deltas-claude5.md`. The five that matter most:

- **Delete verification scaffolding.** Standing instructions to verify, double-check, or spawn a verifier cause over-verification on Opus 5, which self-corrects. Independent author-blind verification by a separate agent is still valuable; instructions telling one agent to re-check itself are not.
- **Prompt for length explicitly.** Effort controls thinking, not visible output. Claude 5 defaults to longer responses than Opus 4.x. If you want short, say so, and say it about written deliverables too.
- **Replace suppression language with coverage-first.** "Only report critical issues" is now followed literally and silently drops real findings. Ask for everything plus a confidence and severity, and filter downstream.
- **Constrain scope for narrow tasks.** Opus 5 expands scope readily. State the intended scope and that the agent should stop at it.
- **Cap delegation.** Opus 5 delegates readily. Say when delegation is warranted, and say that verifying its own work is not one of those times.

## Step 4: check the config surface

Claude 5 rejects several parameters that Claude 4.x accepted. These fail closed with a 400, so they surface fast, but they are worth catching at authoring time:

- `budget_tokens` is removed. Adaptive thinking is on by default; `output_config.effort` is the only depth control.
- Response prefilling is unsupported. Use structured output or explicit format instructions.
- Disabling thinking at `xhigh` or `max` returns 400. If you need thinking off, cap effort at `high`.
- Set `thinking.display` explicitly if any part of the harness surfaces reasoning. Do not rely on the default.

## Reference files

Read the one you need, not all of them.

- `references/model-specs.md`: model strings, pricing, context windows, effort support matrix, tokenizer change
- `references/effort-guide.md`: what each level does, when to step up or down, caching interaction
- `references/prompting-deltas-claude5.md`: the full before and after migration list
- `references/fable-and-mythos.md`: Tier A only. Refusal handling, long-run patterns, Opus fallback

## Quality checklist

- [ ] Capability tier established before routing
- [ ] Every agent has an explicit model and effort, no silent inheritance where a specific model matters
- [ ] No review or audit role below `high`
- [ ] `max_tokens` at 64000 or above wherever effort is `xhigh` or `max`
- [ ] No `budget_tokens`, no prefill, no thinking-disabled at `xhigh` or `max`
- [ ] Verification and double-check scaffolding removed from frontier-role prompts
- [ ] Suppression language replaced with coverage-first plus a downstream filter
- [ ] Response length and deliverable length prompted explicitly
- [ ] Effort held constant across a cached session
