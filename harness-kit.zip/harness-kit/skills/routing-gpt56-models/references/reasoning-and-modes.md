# GPT-5.6 reasoning, modes and caching

All parameters are Responses API unless noted.

## reasoning.effort

Values: `none`, `low`, `medium`, `high`, `xhigh`, `max`. Default is `medium` for GPT-5.6 in both standard and pro mode. `max` is new in 5.6.

The default change matters: earlier GPT-5.x generations defaulted to `none`, so upgraded code silently starts paying reasoning tokens. Set effort explicitly on every call path.

Parallel tool calls are not supported at `minimal` effort where that value applies.

## reasoning.mode

`standard` (default) or `pro`. Pro mode is an execution mode, not a separate model: keep the model string and set the mode. It performs more model work before returning one final answer, is independent of effort, and bills at the selected model's standard token rates.

Use pro mode for high-value review or debugging where a single better answer justifies the extra compute. Do not enable it by default.

## reasoning.context

New in 5.6. Values: `auto` (default), `current_turn`, `all_turns`. Controls persisted reasoning across turns. `all_turns` only has effect when earlier response items are actually available, via `previous_response_id`, an attached conversation, or manual replay. The response echoes the effective value.

## reasoning.summary

`auto`, `concise`, `detailed`. Summaries are opt-in and not returned unless requested. `auto` behaves as `detailed` on most current models. Organization verification may be required.

## text.verbosity

`low`, `medium`, `high`. Sets default output detail. Prefer this over prompt instructions for baseline length, and prompt only for task-specific length requirements.

## max_output_tokens

Caps reasoning plus visible plus formatting tokens. Exceeding it returns `status: "incomplete"` with `incomplete_details.reason: "max_output_tokens"`. OpenAI recommends reserving at least 25,000 tokens for reasoning plus output on reasoning workloads.

## The Chat Completions block

Attaching function tools to a reasoning request on `/v1/chat/completions` returns:

```
400 Function tools with reasoning_effort are not supported for gpt-5.6-sol
in /v1/chat/completions. To use function tools, use /v1/responses or set
reasoning_effort to 'none'.
```

Because 5.6 reasons by default, this fires even with no explicit effort. Chat Completions remains nominally supported but is unusable for agentic work. Migrate.

## Prompt caching

Substantially changed in 5.6.

- Automatic caching activates at 1024 tokens or longer. Routing uses a hash of the initial prefix, typically the first 256 tokens.
- `prompt_cache_options.ttl` currently defaults to `30m` and `30m` is the only supported value. It is a minimum lifetime, not a maximum retention.
- `prompt_cache_options.mode`: `implicit` (default) or `explicit`. In explicit mode with no breakpoints present, the request uses no caching and incurs no write charges.
- `prompt_cache_breakpoint: {"mode": "explicit"}` marks a content block. Supported on `input_text`, `input_image`, `input_file`.
- Up to 4 new cache writes per request; up to the latest 50 breakpoints considered for reads.
- `prompt_cache_retention` is **deprecated** for 5.6 and later. Migrate to `prompt_cache_options.ttl`.
- `prompt_cache_key` must be set on 5.6 to get the improved exact-prefix matching, for both implicit and explicit caching. Keep total traffic per key near 15 requests per minute; partition across more keys above that, with a stable mapping so requests sharing a prefix share a key.
- Cache writes cost 1.25x the uncached input rate on 5.6. Reads bill at the cached-input rate. Track `cached_tokens` and `cache_write_tokens` in `usage.input_tokens_details` and confirm net savings before assuming a long prompt should be cached.

## Programmatic Tool Calling

New in 5.6. Add the `programmatic_tool_calling` tool and opt eligible tools in with `allowed_callers`. The model writes JavaScript executed in an isolated V8 runtime. Programs can call function and custom tools, MCP, apply_patch, shell, and code interpreter. They cannot call web search or file search. Handle `program` items, program-issued function calls, and `program_output` items, preserving `call_id` and `caller`. ZDR-compatible with no extra container cost.

Use PTC for bounded stages where code collapses many or large tool results into a small structured output: filtering, joining, ranking, deduplication, aggregation, validation.

Use direct tool calls when one call suffices, results are already small, each result changes the next decision, an action needs approval, or citations and native artifacts must be preserved.

Tool search must load a deferred tool before the program starts. A running program cannot search.

## Tool search

Add `{"type": "tool_search"}` to the tools array and mark deferred tools `defer_loading: true`. Supported on gpt-5.4 and later. Discovered tools append at the end of context to preserve the cache prefix. The documented pattern disables parallel tool calls. A deferred tool without a paired top-level `tool_search` entry returns 400.

Reach for tool search past roughly 30 tools, where selection accuracy starts degrading and definition tokens become significant.

## Structured Outputs

Current limits, raised from earlier generations:

- Max object properties: 5,000
- Max nesting depth: 5
- Max enum values across the schema: 1,000
- Total character budget for names, definitions and enum values: 120,000
- All fields must be `required`; express optional as a union with null
- `additionalProperties: false` on every object

Responses API uses `text.format` with `type: "json_schema"`; the SDK helper is `responses.parse` with `text_format`. `strict: true` enables constrained decoding on both output schemas and tool definitions. Check the `refusal` field before parsing; treat a refusal as terminal, not retryable.
