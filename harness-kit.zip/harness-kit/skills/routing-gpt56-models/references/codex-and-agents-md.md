# AGENTS.md and Codex configuration

## AGENTS.md

Plain Markdown. Now an open standard under the Agentic AI Foundation. Codex reads AGENTS.md, not CLAUDE.md.

### The size cap

Codex enforces a 32 KiB default cap (32 * 1024 bytes) via `PROJECT_DOC_MAX_BYTES`. Content beyond that is silently truncated with no warning in the TUI. This is the most common way an AGENTS.md quietly stops working. Configure with `project_doc_max_bytes` in config.toml if you must, but the better answer is to stay well under the cap.

### Precedence

Composed from most general to most specific:

1. `~/.codex/AGENTS.override.md`
2. `~/.codex/AGENTS.md` (global)
3. Project root `AGENTS.md`
4. Nested `AGENTS.md` down the directory tree

Only the first non-empty file at each level is used, and Codex stops adding files once the combined size reaches the limit. That means a large root file can silently starve nested ones. Recent CLI versions accept `--print-instructions` to dump the merged result; use it to verify what actually loaded.

### Recommended sections

OpenAI's guidance suggests five categories: repository layout, build and test and lint commands, engineering conventions, testing discipline, and things not to do. Keep it factual. Procedures that grow long belong in a skill or a referenced document, not inline.

### Sharing with a Claude harness

Where a repository serves both Claude Code and Codex, keep one source of truth and reference it. A CLAUDE.md whose first line is `@AGENTS.md` pulls the shared content in without duplicating it. Duplicated instruction files drift within weeks.

## Codex CLI configuration

TOML at `~/.codex/config.toml`.

### Model and reasoning

- `model`, for example `gpt-5.6-sol`
- `model_provider`
- `model_context_window`
- `model_auto_compact_token_limit`: set below 272K to stay under the pricing cliff
- `model_reasoning_effort`: `minimal`, `low`, `medium`, `high`, `xhigh`
- `model_reasoning_summary`: `auto`, `concise`, `detailed`, `none`
- `model_verbosity`: `low`, `medium`, `high`
- `plan_mode_reasoning_effort`

### Sandbox and approvals

These are orthogonal. Sandbox decides what is possible; approval decides when Codex pauses to ask.

- `sandbox_mode`: `read-only`, `workspace-write`, `danger-full-access`. Refined by `[sandbox_workspace_write]` with `network_access` and `writable_roots`. Enforced at OS level: Apple Seatbelt on macOS, Landlock plus seccomp on Linux.
- `approval_policy`: `untrusted`, `on-request`, `never`, plus a granular table form.

### Structure

- `[profiles.*]` for per-task configurations
- `[projects."path"]` for trust levels
- `[mcp_servers]` for MCP
- Enterprise `requirements.toml` to constrain approval, sandbox and MCP allowlists

### Multi-agent

User-triggered only; Codex does not spawn subagents automatically. Enable with `[features] multi_agent = true`, with per-agent `model` and `model_reasoning_effort`.

## Context reality check

The effective input window inside Codex is roughly 272K, against a raw Sol spec of roughly 1.05M. Plan repository context accordingly, and prefer targeted file reads over broad context loading when working through Codex.
