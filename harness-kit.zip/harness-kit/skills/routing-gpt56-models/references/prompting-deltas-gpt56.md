# Prompt migration: GPT-5.x to GPT-5.6

Apply to AGENTS.md, Codex instructions, and any developer message a GPT-5.6 model consumes.

## The governing finding

OpenAI's model guidance reports that on internal coding-agent evals, leaner system prompts improved scores by roughly 10 to 15 percent while reducing total tokens 41 to 66 percent and cost 33 to 67 percent. Their own framing is that these ranges are directional and should be validated on representative tasks from your application.

The mechanism is the same as on the Claude side: 5.6 infers intent better than its predecessors, so instructions that existed to compensate now add noise.

## The deletions

**Repeated instructions.** State each rule exactly once. Repetition across sections is the single largest source of prompt bloat, and it does not increase compliance.

**Repeated approval language.** Lines like "ask first", "do not mutate anything", "wait for approval before changing files" scattered across a prompt cause the model to request approval for safe actions.

- Before: approval reminders in four sections.
- After: one compact autonomy policy, stated once. See below.

**Blanket conciseness.**

- Before: "Be concise."
- After: delete, and set `text.verbosity`. GPT-5.6 is more concise by default than 5.5, and the blanket instruction over-truncates. Prompt for length only where a specific task needs it: "Lead with the conclusion. Keep required facts, decisions, caveats and next steps; trim intros and repetition."

**Step-by-step reasoning instructions.**

- Before: "Think step by step. First consider X, then Y."
- After: delete, and set `reasoning.effort`. Explicit chain-of-thought text wastes tokens on a model that reasons internally.

**Anti-laziness emphasis.**

- Before: "CRITICAL: You MUST. NEVER skip. ABSOLUTELY ESSENTIAL."
- After: calm imperative. Newer models overtrigger on this language.

**Prescriptive step plans for tasks the model can scope itself.** 5.6 infers intent well; enumerating every step is unnecessary and brittle.

## The replacements

**One autonomy and approval policy block:**

```
Answer, review and plan requests: inspect and report. Do not change files.

Change, build and fix requests: make the in-scope changes and run
non-destructive validation without asking.

Require confirmation only for: external writes, destructive actions, and
work that expands scope beyond what was requested.
```

**A tool orchestration block where Programmatic Tool Calling is in play:**

```
<tool_orchestration>
Use PTC for: <the bounded stage, e.g. filtering and ranking search results>
Eligible tools: <list>
Output schema: <shape>
Limits: <concurrency, retries, stopping condition>
Everything else stays as direct tool calls.
</tool_orchestration>
```

**Explicit effort configuration rather than prompt-side reasoning control.** Set `reasoning.effort` per call path, and `reasoning.mode: "pro"` only where a measured gain justifies it.

## Structural conventions that still hold

These carried forward from the GPT-5.x guidance and remain correct:

- Markdown headers as the primary structure; XML or triple quotes for wrapping data.
- Delimiter contrast: if the wrapped content is XML-heavy, use Markdown delimiters, and vice versa. The delimiter should stand out from the content.
- Static content first, variable content last, for cache prefix stability.
- Positive framing over negative constraints.
- Examples must agree with instructions. Where they conflict the model follows the examples.
- Tool descriptions get the same care as prompts. Write them for a new hire, not as API reference.
- Actionable error strings. "InvalidDateFormat: expected YYYY-MM-DD, received '03-15'" rather than "Error 400".

## Migration mechanics

Codex can auto-migrate a project via the OpenAI Docs skill. Whether you use it or hand-edit, re-run your own evals after the prompt cut rather than assuming the reported gains transfer.
