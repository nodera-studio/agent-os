# GPT-5.6 specifications and the writer decision

Verified against OpenAI documentation as of 25 July 2026. GPT-5.6 released 9 July 2026.

## Naming

The number is the generation; Sol, Terra and Luna are durable capability tiers that persist across generations. `gpt-5.6` aliases to `gpt-5.6-sol`.

| Tier | API string | In / Out per MTok | Context (API) | Context (Codex) |
|---|---|---|---|---|
| Sol | `gpt-5.6-sol` | $5 / $30 | ~1.05M spec, 128K reserved output | ~272K effective |
| Terra | `gpt-5.6-terra` | $2.50 / $15 | large | ~272K |
| Luna | `gpt-5.6-luna` | $1 / $6 | large | ~272K |

## The 272K pricing cliff

Requests exceeding 272,000 input tokens are billed at 2x input and 1.5x output **for the entire request**, not the overage. Input, cached input, and cache writes all bill at 2x above the threshold. This applies on Standard, Batch and Flex.

Design consequence: instrument input token counts and hard-stop or compact before 272K. Inside Codex, set `model_auto_compact_token_limit` below it. If a workload routinely needs more than roughly 250K input, split the task or move reference material behind tool search rather than paying doubled rates.

## The Codex context cap

The raw Sol spec is roughly 1.05M context. Inside Codex the effective input window is far smaller. A metadata change around 18 to 19 July 2026 reduced the reported window from roughly 372K to 272K, aligning it with the pricing cliff. Community reports (openai/codex issues) document the reduction.

Practical effect: routing heavy repository context through Codex hits compaction far earlier than the model spec suggests. This is a real constraint on using Codex as a primary implementer in a large monorepo.

## Evidence for the writer decision

Published figures relevant to choosing an implementer, as of late July 2026:

| Benchmark | Opus 5 | GPT-5.6 Sol | Notes |
|---|---|---|---|
| SWE-bench Pro | 79.2% | 64.6% | Multi-file diffs from actively maintained repos. Closest proxy for production work |
| Frontier-Bench v0.1 | 43.3 | 34.4 | Agentic coding |
| SWE-bench Verified | ~97% | ~96.2% | Near-saturated; does not discriminate |
| Terminal-Bench 2.1 | 83.4% (Fable 5) | 88.8% | Run in OpenAI's Codex harness |
| Coding Agent Index | 77 (Fable 5) | 80 (Sol max) | Also Codex-harness |

Read this honestly. The benchmarks where Sol leads are run inside OpenAI's own harness, which flatters Sol and does not represent a Claude Code harness. The benchmarks where Opus 5 leads are vendor-collated too. The signal that survives scrutiny is the SWE-bench Pro gap on real repositories, which is large and in Opus 5's favor, combined with the Codex context cap.

Also relevant: Cursor's June 2026 research audited 731 benchmark runs and found 63 percent of the top model's SWE-bench Pro solves were answer lookups rather than reasoning, with 14 to 21 point drops across models under a strict harness. Treat all of these numbers as directional and validate on your own tickets.

## Recommendation

Retire Codex as default implementer in a Claude-first harness. Keep it as the independent review, debug adversary, and audit engine, which is where a second model family earns its place. Revisit if Opus 5's success rate on your own representative tickets trails Sol-in-Codex by more than a few points, or if the harness is OpenAI-native.
