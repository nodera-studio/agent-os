---
name: routing-gpt56-models
description: Selects the GPT-5.6 tier and reasoning effort for OpenAI-backed lanes in a Claude Code harness, configures Codex and AGENTS.md, and rewrites prompts for GPT-5.6. Covers Sol, Terra and Luna, reasoning effort none through max, pro mode, persisted reasoning, verbosity, Programmatic Tool Calling, prompt caching, the 272K pricing cliff, and GPT-5.x to GPT-5.6 migration. Use this skill whenever a harness routes work to Codex or the OpenAI API, whenever editing AGENTS.md or Codex config, and whenever deciding which lanes should be cross-model rather than Claude-only.
---

# Routing GPT-5.6 models

In a Claude-first harness, OpenAI's job is not to be a second implementer. It is to disagree. A different model family catches different bugs, and that independence is the entire reason to keep the lane. Route accordingly.

## Step 1: decide which lanes are OpenAI lanes

The default split for a Claude-first harness:

| Lane | Owner | Reasoning |
|---|---|---|
| Implementation, code writing | **Claude (Opus 5)** | Leads real-repository coding. See `references/model-specs.md` for the evidence |
| Independent review, second opinion | **GPT-5.6 Sol** | Cross-model disagreement is the point. Same-family review correlates too strongly |
| Debug adversary, second investigator | **GPT-5.6 Sol** | Fresh context plus a different family beats a same-family adversary |
| Multi-engine audits | **Both** | Run Claude and Codex passes and fold the results |
| Orchestration, planning | **Claude** | Keep the control plane in one family |
| Tests, docs, retrieval | **Claude (Sonnet 5)** | No cross-model benefit; cheaper in-family |

The historically common pattern of routing all code writing through Codex is now inverted. Two reasons: on real-repository coding benchmarks Opus 5 leads Sol by a wide margin, and Codex serves a much smaller effective context than the raw model spec implies. Details and numbers in `references/model-specs.md`.

Retire the Codex writer. Keep every Codex review, debug, and audit lane. If a harness is OpenAI-native rather than Claude-first, this inverts and Sol at `xhigh` is a strong writer.

### Cost note

Where Codex runs on a flat-rate subscription that is paid regardless, marginal Codex calls cost quota rather than money. That strengthens the case for keeping review and audit lanes, and it removes the cost argument from the writer decision. The writer decision then rests entirely on performance and context, which still favors Opus 5.

## Step 2: pick the tier and effort

| Tier | API string | In / Out per MTok | Role fit |
|---|---|---|---|
| Sol | `gpt-5.6-sol`, alias `gpt-5.6` | $5 / $30 | Review, debug adversary, hard audits |
| Terra | `gpt-5.6-terra` | $2.50 / $15 | Routine second-opinion passes, bulk audits |
| Luna | `gpt-5.6-luna` | $1 / $6 | Classification, triage, guardrails |

Effort: `none`, `low`, `medium` (default), `high`, `xhigh`, `max`. Orthogonal to effort, `reasoning.mode: "pro"` spends more compute before returning one answer.

Recommended settings: review at Sol `high`, debug adversary at Sol `high`, bulk audit at Terra `medium`, triage at Luna `low` or `none`. Reserve `max` and pro mode for genuinely high-value work and confirm the gain on your own tasks first.

Migration rule from earlier GPT-5.x: start at whatever effort you ran before, then test the same level and one level lower. Do not assume you need more.

## Step 3: the three things that break on upgrade

**Chat Completions no longer works for tool calling.** Attaching function tools to a reasoning request on `/v1/chat/completions` returns 400. Because GPT-5.6 reasons by default, this fires even when no effort is set explicitly. Move every tool-calling path to the Responses API.

**The default effort changed.** GPT-5.6 defaults to `medium`, not `none`. Code that relied on a no-reasoning default now pays reasoning tokens on every call. Set effort explicitly everywhere.

**Prompt caching moved.** `prompt_cache_retention` is deprecated for 5.6 and later, replaced by `prompt_cache_options.ttl`, where `30m` is currently the only valid value. Setting `prompt_cache_key` is now required to get reliable prefix matching, and per-key traffic should stay near 15 requests per minute.

## Step 4: fix the prompt

Full list in `references/prompting-deltas-gpt56.md`. The headline is that leaner wins: OpenAI measured leaner system prompts scoring roughly 10 to 15 percent higher while cutting tokens 41 to 66 percent and cost 33 to 67 percent, on their own coding-agent evals. Treat those as directional and validate on your tasks.

The three highest-value edits:

- State each instruction exactly once. Repetition is the main source of bloat.
- Remove repeated "ask first" and "wait for approval" lines. They cause unnecessary approval requests on safe actions. Replace with one compact autonomy policy.
- Remove blanket "be concise". GPT-5.6 is already more concise than 5.5, and the instruction over-truncates. Use `text.verbosity` for the default.

## Reference files

- `references/model-specs.md`: tiers, pricing, context, the 272K cliff, the Codex context cap, benchmark evidence for the writer decision
- `references/reasoning-and-modes.md`: effort, pro mode, persisted reasoning, verbosity, caching, Programmatic Tool Calling
- `references/prompting-deltas-gpt56.md`: full before and after migration list
- `references/codex-and-agents-md.md`: AGENTS.md spec and precedence, Codex config surface, sandbox and approval modes

## Quality checklist

- [ ] Codex is not the default implementer in a Claude-first harness
- [ ] Codex review, debug, and audit lanes retained
- [ ] Every OpenAI call path uses the Responses API, not Chat Completions
- [ ] `reasoning.effort` set explicitly on every call
- [ ] `prompt_cache_key` set; no `prompt_cache_retention`
- [ ] Input token budget instrumented below 272K
- [ ] AGENTS.md under 32 KiB
- [ ] Each instruction stated once; no repeated approval language
