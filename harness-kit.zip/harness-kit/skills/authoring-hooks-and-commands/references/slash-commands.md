# Slash commands

## The merge

Custom commands and skills have converged. `.claude/commands/deploy.md` and `.claude/skills/deploy/SKILL.md` both create `/deploy` and share the same frontmatter. When both exist with the same name, the skill takes precedence.

Consequence for new work: write user-invocable operations as skills with `user-invocable: true`. You get progressive disclosure, reference files, and per-skill model and effort settings, none of which a flat command file offers. Keep `.claude/commands/` for existing files; there is no urgency to migrate working ones.

## Arguments

`$ARGUMENTS` interpolates the full argument string. Named positional arguments interpolate as `$name`, declared through frontmatter. `argument-hint` supplies the hint shown to the user at invocation.

If `$ARGUMENTS` does not appear anywhere in the body, Claude Code appends `ARGUMENTS: <value>` to the content rather than dropping the input.

## Dynamic context

A backtick-wrapped shell command prefixed with `!` executes and inlines its output before the model reads the file. Useful for current branch, changed files, or a config value that determines behavior.

Use it sparingly. It runs on every invocation, adds latency, and fails awkwardly if the command errors.

## Placement and precedence

Personal (`~/.claude/`), project (`.claude/`), or plugin-provided. Project overrides personal for the same name; plugin commands are namespaced.

## When a command should be something else

| Situation | Better layer |
|---|---|
| Invoked by the user, multi-step, needs reference material | Skill with `user-invocable: true` |
| Should happen automatically, not on request | Hook |
| A single always-true fact | CLAUDE.md |
| Needs its own context window | Subagent, or a skill with `context: fork` |

A command that has grown to several hundred lines with embedded reference tables is a skill that has not been converted yet. The conversion is mechanical: move the body to SKILL.md, split the tables into `references/`, add a description.
