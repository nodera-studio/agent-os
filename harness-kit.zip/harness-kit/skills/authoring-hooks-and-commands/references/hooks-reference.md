# Hooks reference

Verified against Claude Code documentation as of 25 July 2026.

## Contents

- Event list
- Common stdin envelope
- Matcher syntax
- Exit codes
- Output format
- Worked examples

## Event list

Thirty events. Grouped by what they observe.

**Tool lifecycle:** PreToolUse, PostToolUse, PostToolUseFailure, PostToolBatch, PermissionRequest, PermissionDenied

**Session lifecycle:** SessionStart, Setup, SessionEnd, ConfigChange, InstructionsLoaded, CwdChanged

**Turn lifecycle:** UserPromptSubmit, UserPromptExpansion, Stop, StopFailure, MessageDisplay, Notification

**Subagents and tasks:** SubagentStart, SubagentStop, TeammateIdle, TaskCreated, TaskCompleted

**Context:** PreCompact, PostCompact

**Workspace:** FileChanged, WorktreeCreate, WorktreeRemove

**Interaction:** Elicitation, ElicitationResult

In practice five carry nearly every setup: PreToolUse, PostToolUse, UserPromptSubmit, SessionStart, Stop.

## Common stdin envelope

Every event receives JSON on stdin containing at minimum:

```json
{
  "session_id": "...",
  "transcript_path": "...",
  "cwd": "...",
  "hook_event_name": "PreToolUse"
}
```

Most tool and turn events also carry `permission_mode`. Tool and subagent events carry `effort`. Tool events add `tool_name` and `tool_input`; PostToolUse adds `tool_response`.

Command hooks read this on stdin. HTTP hooks receive the same JSON as a POST body.

## Matcher syntax

Tool-name matchers apply only to PreToolUse, PostToolUse, PostToolUseFailure, PermissionRequest and PermissionDenied.

| Form | Example | Matches |
|---|---|---|
| Exact | `Bash` | That tool only |
| Regex | `Edit\|Write` | Either |
| Wildcard | `*` or omitted | All tools |
| MCP | `mcp__server__tool` | A specific MCP tool |

Other events match on their own dimension: SessionStart on `startup`, `resume`, `clear`, `compact`; PreCompact and PostCompact on `manual` or `auto`; SubagentStart and SubagentStop on agent type; FileChanged on literal filenames. UserPromptSubmit, Stop and PostToolBatch take no matcher.

## Exit codes

| Code | PreToolUse | PostToolUse |
|---|---|---|
| 0 | Allow, unless JSON says otherwise | Continue |
| 2 | Block the call | Surface stderr to the model. Cannot undo the call |
| other | Non-blocking error, logged | Non-blocking error, logged |

Default timeout is 60 seconds, configurable.

## Output format

Current contract is `hookSpecificOutput`, which requires `hookEventName`:

```json
{
  "hookSpecificOutput": {
    "hookEventName": "PreToolUse",
    "permissionDecision": "deny",
    "permissionDecisionReason": "..."
  }
}
```

Fields by event:

| Event | Field | Purpose |
|---|---|---|
| PreToolUse | `permissionDecision` | allow, deny, ask |
| PreToolUse | `updatedInput` | Rewrite the tool input |
| PostToolUse | `updatedToolOutput` | Rewrite what the model sees |
| UserPromptSubmit | `additionalContext` | Inject context before the turn |
| SessionStart | `additionalContext` | Inject context at session open |
| Stop, SubagentStop | `additionalContext` | Inject before the turn ends |

`"continue": false` at the top level halts processing and takes precedence over any decision.

The legacy format was a top-level `decision` field (only value `"block"`) plus `reason`. It still works. Prefer `hookSpecificOutput` in anything new.

## Worked examples

**Redirect a tool choice.** PreToolUse on `Bash`, denying in-place stream edits and naming the alternative:

```bash
#!/usr/bin/env bash
input=$(cat)
cmd=$(printf '%s' "$input" | jq -r '.tool_input.command // ""')
if printf '%s' "$cmd" | grep -qE '(^|[|;&[:space:]])sed[[:space:]]+-i'; then
  cat <<'JSON'
{"hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"deny",
"permissionDecisionReason":"Use the Edit tool for in-place file changes rather than sed -i, so the change appears in the transcript and can be reviewed."}}
JSON
  exit 0
fi
exit 0
```

Note the exit 0 with a deny decision, rather than exit 2. The JSON path lets you supply the reason string, which is what actually changes behavior.

**Inject state at session start.** SessionStart returning `additionalContext` with the current branch and dirty file count is cheaper and more reliable than a CLAUDE.md instruction telling the model to check.

**Post-edit validation.** PostToolUse on `Edit|Write` running a formatter or type check, exiting 2 with the error on stderr when it fails. The model sees the failure and fixes it without a round trip through the user.

## Design notes

Steer rather than block where possible. A denial that names the right tool fixes behavior in one turn; a bare denial wastes one.

Write reason strings as instructions to the model, not as error messages to a human. The model is the reader.

Keep hooks fast. They run on the critical path of every matching tool call, and a slow hook is felt on every turn.
