# settings.json and permissions

## Permission rules

Syntax is `ToolName(pattern)`:

```json
{
  "permissions": {
    "deny": ["Read(./.env)", "Read(./secrets/**)", "Bash(curl:*)"],
    "ask": ["Bash(git push:*)"],
    "allow": ["Bash(npm run test:*)", "Read(src/**)"],
    "defaultMode": "default"
  }
}
```

MCP tools take no parentheses: `mcp__server__tool`, or `mcp__server` for a whole server.

## Evaluation order

**deny, then ask, then allow, then defaultMode.** First match wins within a category. Deny always wins, including under `bypassPermissions`, apart from a small set of bypass-immune safety paths such as `.git/`, `.claude/`, `.vscode/` and shell configuration files.

This ordering is the useful property: a deny rule is a genuine guarantee, not a default that a permission mode can override. Anything that must never happen belongs in `deny`, not in a hook and not in a prompt.

## Scope composition

Array settings concatenate and deduplicate across scopes. A project cannot remove a rule that a managed or enterprise setting added.

Design for this when a skill set deploys across several environments. Write agent and hook definitions that work correctly under the most restrictive plausible configuration, rather than assuming a permission mode will be honored. Scope tools explicitly in agent frontmatter rather than relying on `permissionMode`.

Claude Code retains the five most recent timestamped configuration backups.

## Other keys worth knowing

| Key | Purpose |
|---|---|
| `hooks` | Hook registration |
| `model` | Session model, alias or full id |
| `env` | Environment variables |
| `agent` | Default agent for the main conversation |
| `disableBundledSkills` | Turns off shipped skills |
| `skillOverrides` | Per-skill enable and disable |
| `sandbox` | Bash isolation configuration |
| `attribution` | Commit and PR attribution behavior |
| `disableBypassPermissionsMode` | Removes the escape hatch |
| `alwaysThinkingEnabled` | Forces thinking on |
| `additionalDirectories` | Extra readable and writable roots |

## Layering with hooks

Deny rules and hooks overlap. Pick one layer per rule rather than implementing both, which produces confusing double-denials with different reason strings.

Rough division:

- **Deny rule** when the action must never happen and no explanation is needed beyond "not permitted here".
- **Hook** when the action should be redirected, when the decision depends on inspecting the arguments, or when you want to teach the model the right alternative.

The hook's advantage is the reason string. The deny rule's advantage is that it holds under `bypassPermissions`.
