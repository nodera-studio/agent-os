---
name: authoring-hooks-and-commands
description: Writes and audits the deterministic layer of a Claude Code harness: PreToolUse and PostToolUse hooks, session lifecycle hooks, slash commands, and settings.json permission rules. Covers the hook event list, JSON stdin schemas, exit code semantics, the hookSpecificOutput contract that supersedes the legacy decision format, matcher syntax, and permission evaluation order. Use this skill whenever a rule should be enforced mechanically rather than prompted, whenever editing hooks, commands or settings.json, and whenever a model keeps violating an instruction that prompting has failed to fix.
---

# Authoring hooks and commands

Prompts ask. Hooks enforce. When a model repeatedly does something you told it not to do, the answer is usually not a stronger instruction; it is a hook that makes the action impossible or redirects it.

This matters more on the Claude 5 generation, not less. As prompt scaffolding gets deleted, the deterministic layer is what keeps the guarantees that scaffolding used to provide, at zero token cost.

## Decide which layer a rule belongs in

| Rule shape | Layer |
|---|---|
| Must never happen, no exceptions | `settings.json` deny rule |
| Should be redirected to a better tool | PreToolUse hook |
| Should be checked after the fact | PostToolUse hook |
| Context that should always be present at session start | SessionStart hook |
| Always-true project fact | CLAUDE.md |
| Procedural knowledge used sometimes | Skill |
| A repeatable multi-step operation the user invokes | Slash command |

The common mistake is putting deterministic rules in CLAUDE.md, where they consume context on every turn and can still be ignored. If it can be a hook, make it a hook.

## Hooks

Hooks receive JSON on stdin and signal back through exit codes or structured JSON on stdout.

### Events

The reference documents 30 events. Five carry nearly every production setup: **PreToolUse**, **PostToolUse**, **UserPromptSubmit**, **SessionStart**, **Stop**. Full list and per-event schemas in `references/hooks-reference.md`.

### Matchers

Only PreToolUse, PostToolUse, PostToolUseFailure, PermissionRequest and PermissionDenied take tool-name matchers. Syntax: exact string, regex (`Edit|Write`), wildcard (`*` or omitted), MCP (`mcp__server__tool`).

Other events match on their own dimension: SessionStart on source (startup, resume, clear, compact), PreCompact and PostCompact on trigger (manual, auto), SubagentStart and SubagentStop on agent type. UserPromptSubmit and Stop take no matcher.

### Output

Use `hookSpecificOutput`, which requires a `hookEventName` field:

```json
{
  "hookSpecificOutput": {
    "hookEventName": "PreToolUse",
    "permissionDecision": "deny",
    "permissionDecisionReason": "Use Edit rather than sed -i for in-place edits."
  }
}
```

Event-specific fields: `permissionDecision` and `updatedInput` on PreToolUse, `updatedToolOutput` on PostToolUse, `additionalContext` on UserPromptSubmit, SessionStart, Stop and SubagentStop.

The legacy top-level `decision` plus `reason` format still works but is superseded. Use `hookSpecificOutput` for anything new. `"continue": false` halts processing and takes precedence over any decision.

Exit codes: 0 with no JSON allows. Exit 2 blocks on PreToolUse, and on PostToolUse surfaces stderr to the model without undoing the call. Default timeout is 60 seconds.

### Writing a good redirect

The most valuable hooks steer rather than block. A denial with no alternative wastes a turn; a denial that names the right tool fixes the behavior immediately.

```
Bad:  "Command not permitted."
Good: "Use Edit for in-place file changes rather than sed -i, so the change
       is visible in the transcript and can be reviewed."
```

The reason string is read by the model. Write it as instruction, not as an error message.

## Slash commands

Commands and skills have merged. `.claude/commands/deploy.md` and `.claude/skills/deploy/SKILL.md` both produce `/deploy` and share frontmatter. If both exist, the skill wins.

Given that, write new user-invocable operations as skills with `user-invocable: true`, and keep `.claude/commands/` for legacy files. Details in `references/slash-commands.md`.

## settings.json permissions

Rule syntax is `ToolName(pattern)`: `Bash(npm run:*)`, `Write(src/**)`, `Read(./.env)`. MCP tools use `mcp__server__tool` with no parentheses.

Evaluation order: **deny, then ask, then allow, then defaultMode**. First match wins within a category. Deny always wins, including under `bypassPermissions`, except for a small set of bypass-immune safety paths.

Array settings concatenate and deduplicate across scopes, so a project cannot remove a rule a managed setting added. Design for that when a harness deploys into a managed environment.

## Auditing an existing setup

1. **Rules in the wrong layer.** Prompted instructions that should be hooks; hooks that should be deny rules.
2. **Legacy output format.** `decision`/`reason` in new hooks. Works, but migrate.
3. **Blocking without redirecting.** Denials that do not name the alternative.
4. **Missing timeouts.** Hooks that can hang past 60 seconds.
5. **Deny rules that duplicate hooks.** Pick one layer per rule.
6. **Hooks compensating for deleted prompt scaffolding that was never actually needed.** Check the rule still earns its place before porting it forward.

## Quality checklist

- [ ] Each rule lives in exactly one layer
- [ ] New hooks use `hookSpecificOutput` with `hookEventName`
- [ ] Every denial names a better alternative in its reason string
- [ ] Matchers scoped to the tools that need them, not `*`
- [ ] Deny rules cover anything that must never happen, independent of hooks
- [ ] Hook scripts complete well within 60 seconds
- [ ] New user-invocable operations written as skills, not commands
