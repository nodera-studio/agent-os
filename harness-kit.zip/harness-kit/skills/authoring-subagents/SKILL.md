---
name: authoring-subagents
description: Writes, audits and refactors Claude Code subagent definition files under .claude/agents/. Covers YAML frontmatter fields and valid values, description text that routes reliably, tool scoping and denylists, permission modes, isolation and nesting, structured output contracts between agents, and the judgment of when delegation is worth it versus when it wastes tokens. Use this skill whenever creating or editing an agent definition, whenever a harness has agents that trigger at the wrong times or duplicate each other's work, and whenever deciding whether a task warrants a subagent at all.
---

# Authoring subagents

A subagent is a fresh context window with a job description. Two things determine whether it earns its cost: whether the description routes correctly, and whether the job was worth isolating in the first place. Most harness bloat comes from getting the second one wrong.

## Before writing: should this be a subagent

Delegation buys a clean context window and parallelism. It costs a full context re-establishment, a serialization boundary, and coordination overhead. It is worth it when the work is large, genuinely independent, and returns a summary far smaller than the context it consumed.

Delegate when:

- The task is a sizeable independent track that can run in parallel with other tracks.
- The task will consume tens of thousands of tokens of exploration but returns a short answer.
- The task needs a genuinely fresh perspective, for example an author-blind review or an adversarial second opinion.
- The task needs different permissions or a different model than the caller.

Do not delegate when:

- The caller could finish it in a handful of tool calls.
- The subagent would need most of the caller's context to do the job, which means you pay to rebuild it.
- The purpose is to verify the caller's own work. Frontier models self-correct; a same-context verifier mostly agrees with itself. If you want verification, use a separate agent with no knowledge of how the work was done.
- You are adding a step because the workflow looks incomplete without one. That is not a reason.

Claude 5 models delegate readily. In a Claude 5 harness the failure mode is too many subagents, not too few. Full reasoning in `references/when-not-to-delegate.md`.

## Writing the file

```
---
name: agent-name
description: <what it does, and when to route to it>
model: inherit
effort: high
tools: [Read, Grep, Glob, Edit, Write, Bash]
---

<system prompt in markdown>
```

Field reference with valid values in `references/frontmatter-reference.md`. The fields that matter most:

**`name`**: lowercase with hyphens. Required.

**`description`**: required, and it is the routing mechanism. Write it as what the agent does plus when to invoke it. Include the concrete conditions, because the calling model matches against this text and nothing else. Vague descriptions produce agents that never trigger or trigger constantly.

- Weak: "Reviews code."
- Strong: "Reviews implemented changes for correctness, security and production readiness. Use after any non-trivial implementation, before merging, and whenever the user asks for a review or second opinion on a diff."

**`model`**: `inherit` by default, so frontier roles follow the session model. Pin explicitly where the role should always be cheap (`sonnet`, `haiku`) or always be strong regardless of session. Avoid pinning versioned strings on frontier roles; they rot.

**`effort`**: `low` through `max`. Set it deliberately. See the routing skill for which level suits which role.

**`tools`** and **`disallowedTools`**: scope both. `disallowedTools` is applied before `tools`. Omitting `tools` inherits everything, which is usually wrong for a specialist. A researcher does not need Write. A reviewer does not need Edit.

## The system prompt

Keep it short. A subagent prompt should establish the role, the boundaries, and the output contract, then stop. Everything else the model already knows.

Structure that works:

1. Role and scope, two or three sentences.
2. What the agent does, as imperative steps only where order matters.
3. Boundaries: what is explicitly out of scope.
4. Output contract: exactly what to return, in what shape.

Do not include: standing verification instructions, double-check language, "be thorough" or "be concise" without specifics, prescriptive chain-of-thought, or aggressive emphasis. On Claude 5 these range from wasted tokens to actively harmful. The routing skill's `prompting-deltas-claude5.md` has the full list.

## Output contracts

A subagent that returns prose forces the caller to parse prose. Specify the return shape, keep it small, and make it consistent across agents that feed the same consumer.

The default target is a condensed summary in the low thousands of tokens, not a transcript. If a subagent needs to hand over large artifacts, have it write to the filesystem and return the paths. Patterns in `references/output-contracts.md`.

## Auditing an existing set

When handed a harness with many agents, look for these in order:

1. **Agents that never trigger.** Usually a description that describes the role without stating the invocation conditions.
2. **Agents that overlap.** Two descriptions matching the same request means the caller picks arbitrarily. Merge them or sharpen the boundary in both descriptions.
3. **Self-verification chains.** An agent whose job is to check the previous agent's work in the same context. Collapse or make it genuinely blind.
4. **Unscoped tools.** Specialists inheriting the full tool set.
5. **Stale model pins.** Versioned model strings on frontier roles.
6. **Prompt scaffolding.** Verification, double-check, and emphasis language left over from an earlier model generation.

## Quality checklist

- [ ] The delegation is justified by size, independence, or a genuinely fresh perspective
- [ ] `description` states both what it does and when to invoke it
- [ ] No two agents have overlapping trigger conditions
- [ ] `model` and `effort` set deliberately, not by default
- [ ] `tools` scoped to what the role actually needs
- [ ] Output contract specified, small, and consistent with sibling agents
- [ ] System prompt free of verification scaffolding and emphasis language
- [ ] Large artifacts go to the filesystem, not through the return value
