# When not to delegate

Subagents were the right answer more often on Claude 4.x than they are on Claude 5. Two things changed: frontier models now self-correct without being told, and they delegate readily on their own. The result is that harnesses carried forward from the previous generation tend to over-delegate.

## The economics

A subagent costs a fresh context establishment plus a serialization boundary. It pays for itself when the exploration-to-answer ratio is high: the agent burns tens of thousands of tokens searching, reading and reasoning, then returns one or two thousand tokens of conclusion. That compression is the product.

It does not pay when the agent needs most of the caller's context to start. You pay twice for the same context and gain nothing but a boundary.

## Four patterns that look useful and are not

**The self-verifier.** An agent whose job is to check work that was just done in the same conversation, with the same context. It largely agrees with itself. Anthropic's guidance for Claude 5 is explicit that standing verification instructions cause over-verification. Either make verification genuinely blind, meaning a separate agent that sees the artifact but not the reasoning that produced it, or drop the step.

**The pipeline stage that adds no isolation.** Splitting a task into three sequential subagents when one agent could do all three, purely because the workflow diagram looks tidier. Each boundary costs context and loses nuance.

**The redundant reviewer.** Two reviewers from the same model family at the same effort. Their errors correlate. If you want a genuine second opinion, change something material: a different model family, a different context, or an explicitly adversarial framing.

**The specialist that is really a prompt.** An agent that exists to apply one formatting rule or one convention. That is a skill, or a hook, or a line in CLAUDE.md. Agents are for work that needs its own context window.

## What genuinely warrants a subagent

- **Parallel independent tracks.** Three unrelated areas of a codebase that can be explored simultaneously.
- **Deep exploration with a small answer.** Research, codebase archaeology, log analysis.
- **Author-blind review.** An agent that sees the diff but not the reasoning, deliberately.
- **Cross-model adversary.** A different family, specifically to decorrelate errors.
- **Different permissions.** Work that needs write access the caller should not have, or vice versa.
- **Different cost profile.** Bulk mechanical work that should run on a cheaper model.

## Scaling guidance

| Task shape | Agents |
|---|---|
| Simple fact-finding | 1, or none |
| Direct comparison of two or three things | 2 to 4 in parallel |
| Broad research across many areas | Many, with explicitly divided and non-overlapping responsibilities |

The failure mode at scale is not too few agents; it is agents duplicating each other's work because their task descriptions overlapped. Every dispatched agent needs an explicit objective, an output format, and a boundary stating what it should not cover.

## Prompt-side control

In a Claude 5 harness, add an explicit cap to orchestrator prompts rather than relying on default judgment:

```
Delegate only for large, genuinely independent, parallelizable tracks.
Do not delegate work you can finish in a handful of tool calls, and do not
delegate verification of your own work.
```
