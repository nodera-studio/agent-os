# Output contracts between agents

A subagent's return value is an interface. Unspecified interfaces produce callers that parse prose with regular expressions.

## Size

Target a condensed summary in the low thousands of tokens. The whole point of a subagent is compression: it explores widely and returns narrowly. An agent that returns its full working defeats the purpose and pollutes the caller's context.

For large artifacts, write to the filesystem and return paths. This is strictly better than passing content through the return value: the caller loads only what it needs, and the artifact survives context compaction.

## Shape

Specify the shape in the agent's system prompt. Three patterns, in rough order of preference:

**Structured findings**, for review, audit and analysis roles:

```
For each finding:
- location: file and line
- severity: critical | warning | info
- confidence: high | medium | low
- issue: what is wrong
- why: why it matters
- fix: the specific change

Close with a one-paragraph assessment. Return an empty findings list if
there is nothing to report.
```

Note the confidence and severity fields. They exist so a downstream filter can rank, which is what lets you ask for full coverage rather than suppressing findings at source.

**Paths plus a summary**, for agents producing artifacts:

```
Return:
- artifacts: list of file paths written
- summary: two to four sentences on what was produced and any caveats
- blockers: anything that prevented completion, or empty
```

**A decision plus reasoning**, for agents that answer a question:

```
Return:
- answer: the direct answer, first
- evidence: the specific facts supporting it
- confidence: high | medium | low
- gaps: what you could not determine
```

## Consistency across siblings

Agents that feed the same consumer must return the same shape. A synthesizer folding results from three reviewers cannot do its job if each reviewer invented its own format. When auditing a harness, check sibling agents for contract drift; it accumulates silently as agents are edited individually.

## Reporting failure

Every contract needs a failure path. An agent that cannot complete its task should say so explicitly rather than returning a plausible partial result. Add to the contract:

```
If you cannot complete the task, return what you found, state plainly what
blocked you, and do not fill the gap with inference.
```

This matters more on Claude 5 than it did previously, because the models are better at producing confident, coherent output from incomplete information.

## Do not specify

Do not dictate the agent's internal process in the contract. The contract governs what comes back, not how the agent thinks. Prescriptive step plans in a model with adaptive thinking are counterproductive.
