# Subagent frontmatter reference

Fields for `.claude/agents/*.md`. Verified against Claude Code documentation as of 25 July 2026.

## Required

| Field | Values | Notes |
|---|---|---|
| `name` | lowercase, hyphens | Identifier |
| `description` | free text | The routing mechanism. State what it does and when to invoke it |

## Model and reasoning

| Field | Values | Notes |
|---|---|---|
| `model` | `sonnet`, `opus`, `haiku`, `inherit`, or a full model id | Defaults to `inherit`, which uses the parent conversation's model |
| `effort` | `low`, `medium`, `high`, `xhigh`, `max` | One reference indicates `max` is Opus-only in this context |

Model resolution order, highest priority first: the `CLAUDE_CODE_SUBAGENT_MODEL` environment variable, a per-invocation parameter, frontmatter, then the main session model.

## Tools and permissions

| Field | Values | Notes |
|---|---|---|
| `tools` | list | Allowlist. Inherits all tools if omitted. Supports `Agent(agent_type)` for nested dispatch; the older `Task(agent_type)` alias still works |
| `disallowedTools` | list | Denylist. Applied **before** `tools`. Accepts `mcp__server` and `mcp__*` patterns |
| `permissionMode` | `default`, `acceptEdits`, `dontAsk`, `bypassPermissions`, `plan`, `auto` | A parent running `bypassPermissions`, `acceptEdits` or `auto` takes precedence; the subagent cannot escalate or de-escalate against it |

## Execution control

| Field | Values | Notes |
|---|---|---|
| `maxTurns` | integer | Hard cap on agent loop iterations |
| `background` | boolean | Non-blocking dispatch |
| `isolation` | e.g. `worktree` | Runs the agent in an isolated working tree |
| `initialPrompt` | string | Seeds the agent's first turn |

## Composition

| Field | Values | Notes |
|---|---|---|
| `skills` | list | Skills available to this agent |
| `mcpServers` | list | MCP servers available to this agent |
| `memory` | `user`, `project`, `local` | Memory scope |
| `hooks` | object | Agent-scoped hook registration |
| `color` | string | Display only |

Boolean fields accept yes/no, on/off, and 1/0 in recent versions. Older versions accept only true/false.

## Discovery and precedence

Highest priority first: managed settings, the CLI `--agents` flag, project (`.claude/agents/`), user (`~/.claude/agents/`), then plugin-provided agents.

Subagents nest up to 5 levels deep in recent versions. The dispatch tool was renamed from Task to Agent; old aliases still resolve.

## Portability note

When a skill set deploys across several harnesses, do not assume every field is available in every deployment. Managed and enterprise configurations can lock `permissionMode` and restrict MCP. Write agent files that degrade gracefully: scope tools explicitly rather than relying on a permission mode being honored.
