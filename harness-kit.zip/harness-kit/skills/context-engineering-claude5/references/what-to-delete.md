# What to delete

The catalog. Each entry gives the pattern, why it now hurts, and the replacement if any.

## Delete outright

### Standing verification instructions

**Pattern:** "Include a final verification step." "Verify your changes before finishing." "Use a subagent to confirm the work is correct."

**Why:** Claude 5 verifies its own work and iterates without instruction. Explicit verification instructions cause over-verification, which costs tokens and turns.

**Keep instead:** Author-blind verification by a different agent that sees the artifact but not the reasoning that produced it. That is an independent signal. Self-verification is not.

### Double-check language

**Pattern:** "Double-check your answer." "Re-verify before responding." "Confirm your reasoning is sound."

**Why:** Compounds with built-in self-correction. No measured benefit.

### Emphasis and anti-laziness language

**Pattern:** "CRITICAL:", "You MUST", "NEVER skip this", "ALWAYS check EVERY file", "This is ABSOLUTELY ESSENTIAL."

**Why:** Calibrated for older models that under-triggered. Newer models overtrigger on it, producing excessive tool calls and defensive behavior.

**Replacement:** the same rule as a calm imperative. "Use this tool to inspect file structure before editing."

### Prescriptive reasoning plans

**Pattern:** "Think step by step. First consider X, then evaluate Y, then conclude Z."

**Why:** Adaptive thinking is on by default. Prescribing the reasoning path can degrade performance relative to letting the model plan.

**Replacement:** set effort. Depth is a parameter now, not a prompt.

### Forced progress narration

**Pattern:** "Provide a summary after each tool use." "Report status at each step."

**Why:** Claude 5 narrates agentic progress natively. Forcing it produces redundant chatter.

**Replacement:** tune the cadence if the default is wrong. "One sentence before the first tool call. Brief updates only on important findings."

### Context budget warnings

**Pattern:** "Be mindful of your remaining context." "Do not run out of context."

**Why:** Claude 5 tracks its own budget and compaction is handled by the harness.

## Replace

### Suppression language

**Pattern:** "Only report critical issues." "Be conservative." "Do not nitpick." "Focus on high-severity only." "Skip minor issues."

**Why:** Claude 5 follows these literally and silently drops real findings. On review and audit roles this is the single most damaging leftover.

**Replacement:**

```
Report every issue you find, including ones you are uncertain about or
consider low severity. Do not filter for importance or confidence at this
stage; a separate step will do that. For each finding, include a confidence
level and an estimated severity so a downstream filter can rank them.
```

Requires a downstream filter to exist. Add one if it does not.

### Conciseness instructions

**Pattern:** "Be concise." "Keep it short."

**Why:** Effort controls thinking, not visible output length, and Claude 5 defaults longer than Opus 4.x. The bare instruction under-specifies.

**Replacement:** two rules, because response length and deliverable length are different problems.

```
Lead with the answer. Keep the response focused, with most of the length on
substance rather than preamble or recap.

Match document length to what the task needs. Do not pad with filler
sections, redundant summaries, or boilerplate.
```

### Hedged instructions

**Pattern:** "usually do X", "try to avoid Y", "where possible, prefer Z".

**Why:** Claude 5 follows instructions literally and generalizes less silently. Hedges get read narrowly or ignored.

**Replacement:** state the rule and its exception explicitly, or drop the hedge.

## Add, if absent

These are new requirements rather than deletions, because Claude 5 behaviors need bounding that older models did not.

### Scope constraint

```
Deliver what was asked at the scope intended. Make routine judgment calls
without checking in. Finish the whole task and stop short of work beyond it.
```

Opus 5 expands scope readily.

### Delegation cap

```
Delegate only for large, genuinely independent, parallelizable tracks. Do not
delegate work you can finish in a handful of tool calls, and do not delegate
verification of your own work.
```

Opus 5 delegates readily.

### Assessment versus action separation

```
When the user is describing a problem, report findings and hold the fix until
asked.
```

Prevents unrequested edits during diagnosis.

## Test before deleting

Some rules look like leftovers but encode a real project constraint. Before deleting a rule you did not write, check whether the model actually violates the constraint without it. Where it does, keep the rule and annotate it:

```
<!-- Kept 2026-07: model still writes to the legacy schema without this. -->
```

Annotated rules survive future audits for the right reason. Unannotated ones get deleted on the next pass regardless of whether they were load-bearing.
