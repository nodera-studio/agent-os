# The /doctor pass

## What it is

`/doctor` is a bundled Claude Code skill that runs a setup checkup and encodes rightsizing guidance for instruction files and skills. It is available even when bundled skills are disabled, and can be hidden through an environment variable or a skill override.

## How to use it in an audit

Run it after your own pass, not before. Its value is as a second opinion on judgment calls you have already made. Running it first tends to anchor the audit on what the tool noticed rather than on what actually costs you quality.

Read every suggestion. Accept the ones you agree with. It has no visibility into why a given rule exists in your project, so it cannot distinguish leftover scaffolding from a load-bearing constraint that happens to look like scaffolding.

## What it will not catch

`/doctor` checks structure and setup. It does not know:

- Which rules encode a real project constraint versus which are cargo
- Whether a review agent's prompt contains suppression language that is silently costing findings
- Whether two skills have overlapping trigger conditions
- Whether an agent's model and effort suit its role

Those are judgment calls that need the routing and authoring skills.

## Sequencing a full harness audit

1. Delete by category using `what-to-delete.md`. Batch by category so the signal is clean.
2. Rebalance content across CLAUDE.md, skills, hooks and path-scoped rules.
3. Fix model and effort routing on every agent.
4. Audit skill descriptions for trigger overlap and missing conditions.
5. Run `/doctor` and accept what you agree with.
6. Run your evaluation set and compare against the pre-audit baseline.
7. Restore only the specific rules that recover a measured drop, annotated with why.

Step 6 is the one people skip. Without it an audit is a guess, and a plausible-looking cut that removed something load-bearing will not surface until it costs you a production incident.

## Building a baseline if none exists

Five to ten representative tasks with a clear pass condition is enough to detect a meaningful regression. Real tickets from the repository's history work better than synthetic ones, because they exercise the conventions the instruction files exist to encode.

Record tokens and wall-clock alongside pass rate. A cut that holds quality while reducing both is the expected outcome for a Claude 4.x-era harness moving to Claude 5, and if you do not see it, the cut was probably too timid.
