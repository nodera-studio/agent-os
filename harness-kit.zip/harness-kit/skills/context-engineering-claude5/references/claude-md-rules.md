# CLAUDE.md and path-scoped rules

## What belongs here

CLAUDE.md is for facts a competent engineer new to the repository would still get wrong with full access to the code:

- Stack and architecture that is not obvious from the tree
- Naming, layering and boundary conventions the codebase enforces
- Build, test and lint entry points where they are non-standard
- Domain vocabulary
- Non-obvious constraints, with the reason attached

## What does not

| Content | Where instead |
|---|---|
| Long procedures used occasionally | A skill; the body loads on demand |
| Exhaustive reference tables | A skill's `references/` |
| Rules that must hold regardless of reasoning | A hook or a deny rule |
| Rules that apply only to some paths | Path-scoped rules |
| Generic software engineering advice | Nowhere. The model knows |
| Session state | A SessionStart hook injecting `additionalContext` |

A long procedure in CLAUDE.md is the worst possible placement: loaded every turn, used rarely. Moving it into a skill is usually the largest single win in an audit.

## Length

Roughly 200 lines is a reasonable ceiling for most projects. Past that, the content is almost always procedural rather than factual, and belongs in a skill.

## Imports

`@path` imports another file. The main use is sharing one source of truth across harnesses: a CLAUDE.md whose first line is `@AGENTS.md` keeps a Claude harness and a Codex harness aligned without maintaining two files that drift.

Imports still consume context when resolved. Importing a large file saves nothing; it just moves where the text lives.

The chained-import hop limit is commonly cited as 5 but was not confirmed against primary documentation. Do not build a chain that depends on the exact number.

CLAUDE.md files in `--add-dir` directories are not loaded unless the corresponding environment variable is set. Do not assume additional directories bring their instructions with them.

## Path-scoped rules

Rules that apply to a subset of the tree should load only when that subset is touched. This keeps the always-on context small while preserving specificity.

Good candidates: framework-specific conventions in one package, generated-code directories that should not be edited by hand, test conventions that differ from source conventions, security-sensitive paths needing extra care.

The general principle: specificity should cost context only when it is relevant.

## Annotating

Non-obvious rules need a reason. Two benefits: the model generalizes better from an explained rule than a bare one, and the next person auditing knows whether it is safe to delete.

```
- Write migrations forward-only. The staging database is restored from
  production nightly, so down-migrations are never run and drift silently.
```

Better than "Never write down-migrations", both for the model and for the reader.

## Monorepo layering

In a monorepo, a root CLAUDE.md carrying universal facts plus per-package files carrying local conventions works well. Keep the root file genuinely universal. Content that applies to one package tends to migrate upward over time and quietly becomes always-on cost.
