---
name: context-engineering-claude5
description: Prunes and restructures CLAUDE.md, path-scoped rules, always-on preambles and long agent prompts for the Claude 5 generation. Applies the judgment-over-rules philosophy, identifies scaffolding that Claude 5 no longer needs and that now costs quality, and rebalances content across CLAUDE.md, skills, hooks and reference files. Use this skill whenever editing CLAUDE.md or a rules directory, whenever a harness carried forward from an earlier model generation feels bloated or over-instructed, and whenever a prompt has grown long enough that nobody is sure which parts still earn their place.
---

# Context engineering for Claude 5

The work here is mostly deletion. Anthropic removed over 80 percent of Claude Code's system prompt for the Claude 5 generation with no measurable loss on their coding evaluations. Most harnesses carried forward from Claude 4.x are in the same position and have not been cut yet.

This is not a token-saving exercise. Several categories of leftover instruction actively degrade Claude 5 output. Verification scaffolding causes over-verification. Suppression language silently drops real findings. Prescriptive step plans fight adaptive thinking. Cutting them makes the harness both cheaper and better, which is unusual and worth exploiting.

## The philosophy

Older models needed rules because they lacked judgment. Claude 5 has judgment and follows instructions literally. That inverts the design:

- **Instruct where the model cannot know.** Project conventions, domain facts, non-obvious constraints, anything specific to this repository.
- **Do not instruct where the model can work it out.** How to write good code, when to read a file before editing it, that it should not delete things carelessly.
- **Enforce mechanically what must hold.** A hook or deny rule is free at inference time and cannot be reasoned around.

The test for any line in CLAUDE.md: would a competent engineer new to this repository, with full access to the code, still get this wrong? If no, delete it.

## The audit

Work through in this order. Details and the full catalog in `references/what-to-delete.md`.

**1. Verification scaffolding.** Any standing instruction to verify, double-check, re-verify, or spawn a verifier for one's own work. Delete. Keep genuinely independent, author-blind verification performed by a different agent.

**2. Suppression language.** "Only report critical", "be conservative", "do not nitpick". These now work literally and hide real findings. Replace with coverage-first plus a downstream filter.

**3. Emphasis and anti-laziness language.** "CRITICAL", "You MUST", "NEVER skip", "ALWAYS check EVERY". Newer models overtrigger on this. Rewrite as calm imperatives.

**4. Prescriptive reasoning plans.** "Think step by step, first consider X". Adaptive thinking is on by default; these can degrade performance.

**5. Hard rails the model no longer needs.** Rules that existed to prevent behaviors Claude 5 does not exhibit. Test each one before deciding.

**6. Conciseness instructions.** "Be concise" does not work the way it used to, because effort controls thinking rather than visible length. Replace with explicit length calibration, and add a separate rule for written deliverable length.

**7. Duplicated instructions.** The same rule stated in CLAUDE.md, a preamble and three agent prompts. State it once, at the broadest scope where it is true.

## Rebalancing across layers

Deletion is half the job. The other half is moving content to where it costs less.

| Content | Belongs in |
|---|---|
| Always-true project facts, conventions, stack | CLAUDE.md |
| Procedural knowledge used sometimes | A skill, where the body loads on demand |
| Long reference material | A skill's `references/`, effectively free until read |
| Rules that must hold regardless of reasoning | Hooks and deny rules |
| Rules that apply only to certain paths | Path-scoped rules, loaded on match |
| Session state the model should always have | A SessionStart hook injecting `additionalContext` |

A long procedure sitting in CLAUDE.md is the most expensive possible placement: loaded every turn, used rarely. Moving it into a skill is usually the single biggest win in an audit.

## CLAUDE.md specifics

Keep it short. Roughly 200 lines is a reasonable ceiling for most projects; past that, look for content that belongs in a skill.

Import syntax is `@path`. A CLAUDE.md whose first line is `@AGENTS.md` shares one source of truth with a Codex-facing harness rather than maintaining two that drift. Imports still consume context when resolved, so importing a large file is not a saving.

The documented hop limit for chained imports is commonly cited as 5 but was not confirmed against primary documentation during research. Do not build a deep import chain that depends on it.

CLAUDE.md files from `--add-dir` directories are not loaded unless the corresponding environment variable is set.

## Running /doctor

`/doctor` is a bundled skill that performs a setup checkup and encodes rightsizing guidance for instruction files and skills. Run it, read the suggestions, and accept the ones you agree with. It is a useful second opinion on an audit, not a replacement for one. Notes in `references/doctor-pass.md`.

## Validating a cut

Cut, then measure. If a harness has an evaluation set, run it before and after. If it does not, this is the moment to build a small one: five to ten representative tasks with a clear pass condition.

When quality drops after a cut, restore only the specific rules that recover it, and annotate each with why it exists. An annotated rule survives the next audit; an unannotated one gets deleted again in six months, correctly or otherwise.

Cut in batches by category rather than line by line. Deleting all verification scaffolding at once gives a clean signal; deleting seventeen unrelated lines does not.

## Quality checklist

- [ ] No standing self-verification or double-check instructions
- [ ] No suppression language in review or audit prompts
- [ ] No emphasis or anti-laziness capitalization
- [ ] No prescriptive step-by-step reasoning plans
- [ ] Length calibrated explicitly, for both responses and written deliverables
- [ ] Every rule stated once, at the broadest scope where it is true
- [ ] Long procedures moved out of CLAUDE.md into skills
- [ ] Must-hold rules moved into hooks or deny rules
- [ ] CLAUDE.md within a sane length for the project
- [ ] Surviving non-obvious rules annotated with why they exist
- [ ] Evaluation run before and after the cut
