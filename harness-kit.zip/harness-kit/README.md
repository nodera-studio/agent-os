# Harness kit: Claude 5 and GPT-5.6

One subagent and six skills for maintaining a Claude Code harness on the July 2026 model generation. Portable: no harness-specific names, paths or agent references. Deploys unchanged across multiple harnesses.

## Contents

```
agents/harness-architect.md
skills/authoring-subagents/            + 3 references
skills/authoring-skills/               + 3 references
skills/authoring-hooks-and-commands/   + 3 references
skills/routing-claude5-models/         + 4 references
skills/routing-gpt56-models/           + 4 references
skills/context-engineering-claude5/    + 3 references
```

## Install

```bash
cp -r agents/harness-architect.md   <target>/.claude/agents/
cp -r skills/*                      <target>/.claude/skills/
```

Restart Claude Code after adding the skills directory the first time. SKILL.md edits are picked up live afterwards.

Verify: the six skills should appear in the skills list, and `harness-architect` in the agent list.

## Capability tiers

`routing-claude5-models` gates Fable 5 behind a tier check rather than forking the routing table.

| Tier | Meaning |
|---|---|
| A | Fable 5 reachable |
| B | Opus 5 is the ceiling |

Tier B routing is a strict subset of Tier A, so a Tier B answer is always safe. The skill assumes Tier B when it cannot determine the tier. If a harness is Tier A, say so when invoking, or record it in CLAUDE.md.

## Suggested rollout

Do not run all of this in one pass. Each step should be validated before the next.

**1. Flip the writer.** Move the primary implementer to Opus 5 at `xhigh` with `max_tokens` at 64000 or above. Keep every Codex review, debug and audit lane. Benchmark on ten representative tickets from the repository's own history, measuring task success, diff quality, tokens and wall-clock.

Reverse if Opus 5's success rate trails the previous writer by more than a few points on your own tickets, or if the harness is OpenAI-native.

**2. Strip verification scaffolding.** Run the deletion pass from `context-engineering-claude5`, batched by category. Re-run the benchmark. Restore only rules that recover a measured drop, annotated with why.

**3. Rewrite prompt files.** Apply the before-and-after lists in both routing skills to agent prompts and any prompt-engineering reference docs the harness carries.

**4. Set the routing matrix.** Opus 5 for frontier roles, Sonnet 5 for mechanical, Haiku 4.5 for classifiers, Fable 5 only for genuine multi-day autonomous runs on Tier A.

**5. Audit descriptions.** Read every agent and skill description in sequence, ignoring bodies. That is what the routing model sees. Fix overlaps and missing invocation conditions.

**6. Run `/doctor`.** Accept what you agree with. It cannot distinguish leftover scaffolding from a load-bearing constraint, so treat it as a second opinion.

## Two unverified items

Both are marked in the reference files. Neither blocks use.

**Haiku 4.5 effort support.** Not listed in Anthropic's published effort matrix. Omitting `output_config.effort` on Haiku roles is always valid. To resolve:

```bash
curl https://api.anthropic.com/v1/messages \
  -H "x-api-key: $ANTHROPIC_API_KEY" \
  -H "anthropic-version: 2023-06-01" \
  -H "content-type: application/json" \
  -d '{"model":"claude-haiku-4-5","max_tokens":16,
       "output_config":{"effort":"low"},
       "messages":[{"role":"user","content":"hi"}]}'
```

200 means supported; 400 naming the parameter means omit it. Record the answer in `routing-claude5-models/references/model-specs.md`.

**`thinking.display` default on Opus 5.** Per-model defaults are not clearly documented. The skills advise setting it explicitly, which is correct regardless of the default, so this only matters if you want to rely on the default.

## Freshness

Every model fact carries a verification date of 25 July 2026. This generation ships frequently. Before a large migration, re-check model strings, pricing, effort support and the Codex context cap against current documentation. The structural guidance on skills, hooks, subagents and context engineering ages more slowly than the model specifics.

## Design notes

**Why one agent and six skills** rather than one large skill: the skills split by concern and by vendor so exactly one vendor's detail loads for a given task, and reference files stay unloaded until needed. A harness working purely in Claude never pays for the GPT-5.6 material.

**Why the skills teach rules rather than encode conventions**: deploying across multiple harnesses means the skills cannot assume a house style. They establish the harness first, then apply rules to what they find. A harness-specific convention belongs in that harness's CLAUDE.md, not in a portable skill.

**Why the Codex writer is retired but the Codex lanes are kept**: cross-model disagreement is where a second family earns its place. Review, debug and audit benefit from decorrelated errors. Implementation does not benefit from a model that trails on real-repository coding and runs in a smaller effective context window. Evidence and the thresholds that would reverse the call are in `routing-gpt56-models/references/model-specs.md`.
